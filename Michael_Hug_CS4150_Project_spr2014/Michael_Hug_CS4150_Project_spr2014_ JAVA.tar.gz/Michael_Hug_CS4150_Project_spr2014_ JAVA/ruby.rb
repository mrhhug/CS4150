def
 	b = -22
 	puts b
 	b = 3
 	puts b
 	b = + 3 1
 	puts b
end
def
	puts 5
end
 def
	c = 6
	while < c 10 do
		c = + c 1
		puts c
	end
	if < c 10
	then puts -111
	else puts -222
	end
	until <= c 1 do
		c = - c 1
		puts c
	end
	puts 222
end
def
	if > c 1 then puts 456 puts 456 puts 456 puts 456 else puts 654 puts 654 puts 654 puts 654 end
	if < c 1 then puts 1 else puts 0 end
	if >= c 1 then puts 1 else puts 0 end
	if <= c 1 then puts 1 else puts 0 end
	if == c 1 then puts 1 else puts 0 end
	if /= c 2 then puts 1 else puts 0 end
	if /= c 1 then puts 1 else puts 0 end
end
