'''
Author : Michael Hug
Author email : hmichae4@students.kennesaw.edu
Student of Prof Gayler cs4150 Spr014
project - Python
Tuesday, March 25th 2014
'''

mem = [0] * 52
lexeme = ("def","end","then","else","do","if","puts"),("while","until"),("=","<=","<",">=",">","==","/="),("+","-","*","/")