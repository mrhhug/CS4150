def
  y = 8
  z = + y 7
  if < y z then
    while < y z do
      y = + y 1
      puts y
    end
  else
    puts 0  
  end
end